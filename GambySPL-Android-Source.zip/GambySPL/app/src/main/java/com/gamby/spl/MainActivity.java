package com.gamby.spl;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Process;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int SAMPLE_RATE = 44100;
    private static final int N = 4096;
    private AudioRecord recorder;
    private volatile boolean running = false;
    private Thread audioThread;
    private TextView live, peakText, avgText, freqText, status, sessions;
    private EditText calibration;
    private double peakDb = -120, sumDb = 0;
    private long frames = 0;
    private double calOffset = 0;
    private SharedPreferences prefs;
    private final int bg = Color.rgb(16,21,29), panel = Color.rgb(27,36,48), white = Color.WHITE, muted = Color.rgb(167,180,197);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("spl", MODE_PRIVATE);
        calOffset = Double.longBitsToDouble(prefs.getLong("cal", Double.doubleToLongBits(0)));
        buildUi();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 9);
    }

    private TextView label(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(color); t.setTextSize(size); t.setGravity(Gravity.CENTER); t.setPadding(8,8,8,8); return t;
    }
    private Button btn(String s) { Button b = new Button(this); b.setText(s); return b; }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,16,18,24); scroll.addView(root);
        TextView title = label("GAMBY SPL METER", 22, white); title.setTypeface(null, Typeface.BOLD); root.addView(title);
        root.addView(label("PHONE MICROPHONE • LIVE SOUND LEVEL", 12, muted));
        live = label("— — — dB", 42, white); live.setTypeface(null, Typeface.BOLD); root.addView(live);
        status = label("STOPPED • Grant microphone permission to begin", 13, muted); root.addView(status);
        peakText = label("PEAK HOLD: — dB", 18, white); root.addView(card(peakText));
        avgText = label("SESSION AVG: — dB", 16, white); root.addView(card(avgText));
        freqText = label("DOMINANT FREQUENCY: — Hz", 16, white); root.addView(card(freqText));
        LinearLayout buttons = new LinearLayout(this); buttons.setGravity(Gravity.CENTER); Button start = btn("START"); Button stop = btn("STOP"); Button reset = btn("RESET PEAK");
        buttons.addView(start,new LinearLayout.LayoutParams(0,-2,1)); buttons.addView(stop,new LinearLayout.LayoutParams(0,-2,1)); buttons.addView(reset,new LinearLayout.LayoutParams(0,-2,1)); root.addView(buttons);
        root.addView(label("CALIBRATION OFFSET (dB)", 14, muted));
        calibration = new EditText(this); calibration.setSingleLine(true); calibration.setText(String.format(Locale.US,"%.1f",calOffset)); calibration.setTextColor(white); calibration.setHint("e.g. +3.0 or -2.0"); calibration.setHintTextColor(muted); root.addView(calibration);
        Button apply = btn("APPLY OFFSET"); root.addView(apply);
        Button save = btn("SAVE TEST SESSION"); root.addView(save);
        root.addView(label("SAVED SESSIONS", 18, white)); sessions = label("No sessions saved yet.", 13, muted); sessions.setGravity(Gravity.START); root.addView(card(sessions));
        TextView warning = label("LIMITATIONS\nPhone microphones are not calibrated SPL instruments. Values are estimates based on digital level plus your offset, not guaranteed absolute dB SPL. Bass response and automatic gain control vary by phone. A clipped signal is flagged and its reading is unreliable. No software ceiling is imposed, but the microphone/ADC still has a physical limit. Use safe listening levels.", 13, Color.rgb(255,190,95)); warning.setGravity(Gravity.START); root.addView(card(warning));
        setContentView(scroll);
        start.setOnClickListener(v -> startMeter()); stop.setOnClickListener(v -> stopMeter());
        reset.setOnClickListener(v -> { peakDb=-120; peakText.setText("PEAK HOLD: — dB"); });
        apply.setOnClickListener(v -> { try { calOffset=Double.parseDouble(calibration.getText().toString().trim()); prefs.edit().putLong("cal",Double.doubleToLongBits(calOffset)).apply(); status.setText("Calibration offset saved: "+calOffset+" dB"); } catch(Exception e) { status.setText("Enter a valid numeric offset."); } });
        save.setOnClickListener(v -> saveSession()); refreshSessions();
    }
    private View card(View child) { LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(8,8,8,8); box.setBackgroundColor(panel); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,6,0,6); box.addView(child); box.setLayoutParams(p); return box; }

    private void startMeter() {
        if (running) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},9); return; }
        int min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) { status.setText("This device does not support the requested audio input."); return; }
        try {
            recorder = new AudioRecord(MediaRecorder.AudioSource.UNPROCESSED, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min,N*2));
            if (recorder.getState()!=AudioRecord.STATE_INITIALIZED) { recorder.release(); recorder = new AudioRecord(MediaRecorder.AudioSource.MIC,SAMPLE_RATE,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,Math.max(min,N*2)); }
            recorder.startRecording(); running=true; status.setText("LIVE • dBFS-derived estimate • watch clipping indicator");
            audioThread = new Thread(this::readAudio,"SPL-Audio"); audioThread.start();
        } catch(Exception e) { running=false; status.setText("Could not start microphone: "+e.getMessage()); }
    }
    private void stopMeter() { running=false; try { if(recorder!=null){recorder.stop();recorder.release();} } catch(Exception ignored){} recorder=null; status.setText("Stopped."); }

    private void readAudio() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
        short[] samples = new short[N];
        while(running && recorder!=null) {
            int got=recorder.read(samples,0,N,AudioRecord.READ_BLOCKING); if(got<=0) continue;
            double squares=0; int clipped=0;
            double[] re=new double[N], im=new double[N];
            for(int i=0;i<got;i++){ double x=samples[i]/32768.0; squares+=x*x; if(Math.abs((int)samples[i])>=32700)clipped++; if(i<N){ double w=0.5-0.5*Math.cos(2*Math.PI*i/(N-1)); re[i]=x*w; } }
            double rms=Math.sqrt(squares/got);
            // RMS relative to full scale; offset is user-calibrated and cannot repair device response.
            double dbfs=20*Math.log10(Math.max(rms,1e-9));
            double displayed=dbfs+calOffset;
            double dominant=dominantFrequency(re,im);
            final boolean isClipped=clipped>Math.max(2,got/100);
            final double d=displayed, f=dominant;
            runOnUiThread(() -> {
                if(!running)return;
                live.setText(String.format(Locale.US,"%.1f dB",d));
                if(d>peakDb){peakDb=d; peakText.setText(String.format(Locale.US,"PEAK HOLD: %.1f dB",peakDb));}
                sumDb+=d; frames++; avgText.setText(String.format(Locale.US,"SESSION AVG: %.1f dB",sumDb/frames));
                freqText.setText(f>0?String.format(Locale.US,"DOMINANT FREQUENCY: %.0f Hz",f):"DOMINANT FREQUENCY: — Hz");
                status.setText(isClipped?"CLIPPING DETECTED — reading unreliable":"LIVE • relative level estimate • calibration offset "+String.format(Locale.US,"%+.1f dB",calOffset));
                status.setTextColor(isClipped?Color.RED:muted);
            });
        }
    }
    private double dominantFrequency(double[] re, double[] im) {
        int n=re.length; if(n<2)return 0;
        // Iterative radix-2 FFT.
        int j=0; for(int i=1;i<n;i++){int bit=n>>1; for(; (j&bit)!=0;bit>>=1)j^=bit; j^=bit; if(i<j){double t=re[i];re[i]=re[j];re[j]=t;}}
        for(int len=2;len<=n;len<<=1){double ang=-2*Math.PI/len; double wr0=Math.cos(ang),wi0=Math.sin(ang); for(int i=0;i<n;i+=len){double wr=1,wi=0;for(int k=0;k<len/2;k++){int u=i+k,v=i+k+len/2;double vr=re[v]*wr-im[v]*wi,vi=re[v]*wi+im[v]*wr;re[v]=re[u]-vr;im[v]=im[u]-vi;re[u]+=vr;im[u]+=vi;double nw=wr*wr0-wi*wi0;wi=wr*wi0+wi*wr0;wr=nw;}}}
        int lo=Math.max(1,(int)(20.0*n/SAMPLE_RATE)), hi=Math.min(n/2-1,(int)(20000.0*n/SAMPLE_RATE)); double max=0;int best=0;
        for(int k=lo;k<=hi;k++){double mag=re[k]*re[k]+im[k]*im[k];if(mag>max){max=mag;best=k;}}
        return best*SAMPLE_RATE/(double)n;
    }
    private void saveSession() {
        if(frames==0){status.setText("Start a measurement before saving a session.");return;}
        String stamp=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date());
        String entry=stamp+" | peak "+String.format(Locale.US,"%.1f",peakDb)+" dB | avg "+String.format(Locale.US,"%.1f",sumDb/frames)+" dB | offset "+String.format(Locale.US,"%+.1f",calOffset)+" dB";
        String old=prefs.getString("sessions",""); prefs.edit().putString("sessions",entry+"\n"+old).apply(); refreshSessions(); status.setText("Session saved.");
    }
    private void refreshSessions(){ if(sessions!=null){String s=prefs.getString("sessions","");sessions.setText(s.isEmpty()?"No sessions saved yet.":s);} }
    @Override protected void onDestroy(){stopMeter();super.onDestroy();}
}
