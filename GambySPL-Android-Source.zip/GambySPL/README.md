# Gamby SPL Meter (Android source project)

Features: live phone-mic level estimate, peak hold, session average, calibration offset, saved sessions, dominant-frequency estimate, and clipping warning. No arbitrary software ceiling is applied to the calculated display value.

## Build an APK
Open this folder in Android Studio (recent version), allow Gradle sync, then select **Build > Build APK(s)**. The APK will normally be at `app/build/outputs/apk/debug/app-debug.apk`.

Command line, with Android SDK installed and configured:
`gradle assembleDebug`

## Measurement notes
- This app reports `dBFS + user calibration offset`, not guaranteed absolute dB SPL. The default offset is 0.0; without calibration against a known SPL reference, values are not valid absolute SPL.
- Phone microphones, automatic gain control, bass roll-off, and ADC limits vary by model. Clipping detection is a warning, not a guarantee that all distortion is detected.
- Dominant frequency is an FFT peak estimate from a 4096-sample window, primarily useful for identifying strong tonal content; it is not a calibrated spectrum analyzer.
- Long-term average is an arithmetic average of displayed block dB readings, not a standards-compliant Leq measurement.
- Competition results should be verified using a sanctioned meter and microphone placement rules.

## Current build status
This environment did not include Android SDK/build-tools or Gradle, so an APK could not be compiled or device-tested here. The source project is provided for building in Android Studio.

## Build the APK without installing Android Studio locally

This project includes `.github/workflows/build-apk.yml` for building the APK on GitHub Actions.

1. Sign in to GitHub and create a new **private** repository (or use a repository you control).
2. Upload the contents of this project folder to the repository's root. Ensure `.github/workflows/build-apk.yml` is included.
3. Open the repository's **Actions** tab and select **Build Gamby SPL Meter APK**.
4. Select **Run workflow** if it has not already run after the upload.
5. When the workflow finishes successfully, open that run and download the `GambySPL-debug-apk` artifact.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`, then transfer it to your Android phone and install it. Android may ask you to allow installs from that source.

The debug APK is unsigned for Play Store distribution but can normally be installed directly for personal use. GitHub may change its UI or action requirements over time.
